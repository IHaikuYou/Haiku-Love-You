# I-Haiku-You

A daily poetry game: choose an image, create a haiku (5-7-5), and share your creation.

## Features

- Daily inspirational image
- 5-7-5 haiku builder with syllable counter
- Social sharing (via copy/paste or native sharing)
- Early access email collection (optional)

## To Run Locally

Open `index.html` in your browser.

---

## Next Steps

- Add a backend (Node/Express, Firebase, etc.) for storing haiku and user data
- Implement user authentication and profiles
- Add email verification or mailing list integration