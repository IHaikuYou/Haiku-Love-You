// Simple syllable counter (heuristic, not perfect)
function countSyllables(str) {
    str = str.toLowerCase().replace(/(?:[^a-z]|ing$)/g, " ");
    if (!str.trim()) return 0;
    return str
        .split(" ")
        .filter(Boolean)
        .reduce((acc, word) => {
            if (word.length <= 3) return acc + 1;
            word = word.replace(/(?:es|ed|e)$/, "");
            const syls = word.match(/[aeiouy]{1,2}/g);
            return acc + (syls ? syls.length : 1);
        }, 0);
}

function updateSyllableCount() {
    const l1 = document.getElementById('line1').value;
    const l2 = document.getElementById('line2').value;
    const l3 = document.getElementById('line3').value;
    const s1 = countSyllables(l1);
    const s2 = countSyllables(l2);
    const s3 = countSyllables(l3);

    document.getElementById('syll1').textContent = `${s1} / 5 syllables`;
    document.getElementById('syll2').textContent = `${s2} / 7 syllables`;
    document.getElementById('syll3').textContent = `${s3} / 5 syllables`;

    // Enable share only if valid haiku
    document.getElementById('share-btn').disabled = !(
        s1 === 5 && s2 === 7 && s3 === 5 &&
        l1.trim().length > 0 && l2.trim().length > 0 && l3.trim().length > 0
    );
}

['line1', 'line2', 'line3'].forEach(id => {
    document.getElementById(id).addEventListener('input', updateSyllableCount);
});

document.getElementById('haiku-form').addEventListener('submit', function(e) {
    e.preventDefault();
    const l1 = document.getElementById('line1').value;
    const l2 = document.getElementById('line2').value;
    const l3 = document.getElementById('line3').value;

    const haikuHtml = `
      <div class="haiku-line">${l1.replace(/</g,"&lt;")}</div>
      <div class="haiku-line">${l2.replace(/</g,"&lt;")}</div>
      <div class="haiku-line">${l3.replace(/</g,"&lt;")}</div>
      <button onclick="navigator.clipboard.writeText(\`${l1}\n${l2}\n${l3}\`);this.textContent='Copied!';" class="signup-btn" style="margin-top:1rem;">Copy Haiku</button>
    `;
    const out = document.getElementById('haiku-output');
    out.innerHTML = haikuHtml;
    out.style.display = 'block';
});

updateSyllableCount();